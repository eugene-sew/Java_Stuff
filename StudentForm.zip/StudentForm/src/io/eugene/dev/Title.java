package io.eugene.dev;

import javax.swing.*;
import java.awt.*;

public class Title extends JLabel {
    Title(){
        setText("Student Registration Form");
        setFont(new Font("Consolas", Font.BOLD, 25));
        setBounds(250,0,600,40);

    }
}

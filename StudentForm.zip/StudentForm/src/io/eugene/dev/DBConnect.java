package io.eugene.dev;

import java.sql.*;
import java.time.LocalDate;

public class DBConnect {
    Connection con;
    Statement statement;
    ResultSet results;

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/students_form", "root", "eugenedev");
            System.out.println("Success Connecting");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void makeQuery(String fname, String lname, String email, String password, LocalDate dob, String gender, String department) {

        try {
//            statement = con.createStatement();
            PreparedStatement statement = con.prepareStatement("insert into  registration(fname,lname,email,password,gender,department,date_of_birth)values (?,?,?,?,?,?,?)");
            statement.setString(1,fname);
            statement.setString(2,lname);
            statement.setString(3,email);
            statement.setString(4,password);
            statement.setString(5,dob.toString());
            statement.setString(6,gender);
            statement.setString(7,fname);



            //    statement = con.prepareStatement("insert into  registration(fname,lname,email,password,gender,department,date_of_birth)values (?,?,?,?,?,?,?)");




            while (results.next()) {
                System.out.println(results.getString("fname"));
            }
            statement.close();

        } catch (SQLException er) {
            er.printStackTrace();
        }
    }


}

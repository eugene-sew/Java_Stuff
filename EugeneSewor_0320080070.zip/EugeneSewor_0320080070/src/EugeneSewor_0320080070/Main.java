package EugeneSewor_0320080070;

public class Main {

    public static void main(String[] args) {
	// write your code here
        new Form();
    }
}
